# Handoff: Copera Currency — app de cotações na barra de menu do macOS

## Visão geral
Copera Currency é um app **macOS de barra de menu** (menu bar / status item) que mostra a cotação de um par de moedas em tempo real, sempre visível ao lado do relógio e do Wi‑Fi. Ao clicar no item da barra abre um **popover** com: conversor de valores, lista de pares acompanhados com variação 24h, favoritos e atualização manual. Uma **janela de Ajustes** nativa permite configurar par exibido, intervalo de atualização, moedas, aparência (claro/escuro) e cor de destaque.

Suporta **moedas fiduciárias e cripto** (USD, BRL, EUR, GBP, JPY, BTC, ETH).

## Sobre os arquivos deste pacote
Os arquivos aqui são **referências de design feitas em HTML** — um protótipo que mostra a aparência e o comportamento pretendidos, **não é código de produção para copiar direto**. A tarefa é **recriar este design em SwiftUI** (app nativo macOS), usando os padrões e bibliotecas nativos da plataforma. O HTML serve só de referência visual e de fluxo.

- `Copera Currency.dc.html` — o protótipo. Abre em qualquer navegador. É um "Design Component" (roda com `support.js` ao lado), então abra os dois juntos. Toda a lógica de estado e os valores de design estão dentro desse arquivo (procure pela classe `Component` no `<script>` e pelo método `theme()` para os tokens de cor).
- `support.js` — runtime do protótipo (só para visualizar o HTML; **não** faz parte da implementação SwiftUI).

> Dica: para ver o protótipo, é mais fácil abrir o `.dc.html` no navegador. O que importa para a implementação são as medidas, cores, tipografia e comportamentos descritos abaixo.

## Fidelidade
**Alta fidelidade (hifi).** Cores, tipografia, espaçamentos e interações são finais. Recrie a UI fielmente usando os controles nativos do SwiftUI.

## Arquitetura SwiftUI sugerida
- **Item da barra de menu:** `MenuBarExtra` (macOS 13+) com `.menuBarExtraStyle(.window)` para abrir um popover/janela customizada (o conteúdo do popover abaixo). O label do `MenuBarExtra` é o texto compacto da cotação.
- **Conteúdo do popover:** uma `View` SwiftUI (largura fixa ~368pt, altura dinâmica).
- **Janela de Ajustes:** cena `Settings { … }` ou uma `Window` separada, com `NavigationSplitView` (sidebar + detalhe) para reproduzir o layout de System Settings.
- **Estado:** um `ObservableObject` (ex.: `RatesStore`) com `@Published` para cotações, par exibido, favoritos, tema, intervalo etc. Persistir preferências em `@AppStorage`/`UserDefaults`.
- **Dados:** um serviço que busca cotações de uma API real (ver "Dados / API"). No protótipo os valores são simulados.
- **Atualização automática:** um `Timer` no intervalo configurado (10s/30s/1m/5m) que rebusca e atualiza `updatedAt`.

---

## Telas / Views

### 1. Item da barra de menu (sempre visível)
- **Propósito:** mostrar a cotação do par escolhido de relance.
- **Conteúdo (formato configurável):**
  - `pair` → `USD/BRL 5.42 ▲`
  - `symbol` → `R$ 5.42 ▲`
  - `plain` → `5.42 ▲`
- **Layout:** linha única; prefixo (peso 600), valor em **fonte monoespaçada tabular** (peso 700), e uma seta de 9px colorida (verde alta / vermelho baixa).
- **Comportamento:** clique abre/fecha o popover. No protótipo o fundo do botão fica `rgba(127,127,130,0.22)` quando o popover está aberto.
- **SwiftUI:** label do `MenuBarExtra`. Use `Text` com `.monospacedDigit()`. A seta segue a variação 24h do par.

### 2. Popover (ao clicar no item)
Largura **368pt**, cantos **13pt**, fundo translúcido com blur (efeito vibrancy — usar `.background(.ultraThinMaterial)` no SwiftUI), borda 0.5pt, sombra grande. Tem um "bico"/seta apontando para o item da barra.

Seções, de cima para baixo:

**a) Cabeçalho** — padding 14pt.
- Título "Exchange Rates" (15pt, peso 700).
- Subtítulo "Updated 4s ago" (11pt, cor secundária) — tempo relativo desde a última atualização.
- À direita: dois botões circulares de 28pt (cantos 8pt, borda 0.5pt, fundo = cor de campo): **↻** (atualizar agora) e **⚙** (abrir Ajustes). Hover clareia o fundo.

**b) Conversor** — card interno (fundo de campo, borda 0.5pt, cantos 12pt, padding 12–14pt).
- Bloco **FROM**: label "FROM" (10pt, peso 600, letter-spacing 0.5px, secundária). Abaixo: `TextField` numérico grande (23pt, peso 700, mono, tabular) + "chip" de moeda à direita (badge circular 20pt com símbolo + código 13pt + chevron ▾). Clicar no chip cicla a moeda.
- Divisor horizontal 0.5pt com botão **⇅** circular de 30pt (cor = accent) à direita → troca FROM/TO.
- Bloco **TO**: igual, mas o valor é **resultado calculado** (read-only), não editável.
- **Cálculo:** todo valor é normalizado em USD. Cada moeda tem um `usd` (valor de 1 unidade em USD). `resultado = quantia × cur[from].usd / cur[to].usd`. A taxa de um par `base/quote = cur[base].usd / cur[quote].usd`.

**c) Lista "TRACKING"** — padding 8–11pt.
- Cabeçalho da seção: "TRACKING" (11pt, peso 600, letter-spacing) + link "Manage" (cor accent) que abre Ajustes › Currencies.
- Cada linha (clicável, hover clareia, cantos 9pt, padding 7pt):
  - Barra vertical de 3pt à esquerda na cor accent **só** no par atualmente exibido na barra de menu (senão transparente).
  - Botão estrela ★/☆ (14pt) — alterna favorito (não propaga o clique da linha).
  - Badge circular 24pt com símbolo da moeda base (fiat: fundo `rgba(128,128,130,0.16)`, texto = cor de texto; **BTC**: fundo `#f7931a`, texto branco; **ETH**: fundo `#627eea`, texto branco).
  - Coluna: par "USD/BRL" (13pt, peso 600) + nome "US Dollar" (11pt, secundária).
  - À direita: cotação (13pt, peso 700, mono tabular) + "pill" de variação (11pt, peso 600, cantos 6pt, padding 1×6) com seta ▲/▼. Verde: texto `var(--pos)`, fundo `rgba(40,165,95,0.14)`. Vermelho: texto `var(--neg)`, fundo `rgba(214,60,50,0.14)`.
  - Clicar na linha define aquele par como o exibido na barra de menu.
  - Ordenação: favoritos primeiro, depois ordem original.

**d) Rodapé** — divisor + linha com "Settings…" (esquerda) e "Quit Copera Currency" (direita), 12pt, cor secundária, hover escurece. "Quit" deve encerrar o app (`NSApplication.shared.terminate`).

### 3. Janela de Ajustes
Janela **680×496pt**, cantos 12pt, sombra grande, layout em duas colunas.

**Sidebar (208pt)** — fundo levemente mais escuro que o conteúdo.
- Topo: três "semáforos" do macOS (12pt: `#ff5f57` vermelho/fechar, `#febc2e` amarelo, `#28c840` verde). Em SwiftUI nativo isso vem da própria janela — não desenhar manualmente.
- Lista de navegação (item selecionado: fundo accent, texto branco; ícone em badge 22pt cantos 6pt):
  - **General** (ícone ⚙, badge `#8e8e93`)
  - **Currencies** (ícone $, badge `#34c759`)
  - **Appearance** (ícone ◐, badge `#5e5ce6`)
  - **About** (ícone i, badge `#0a84ff`)

**Conteúdo (direita)** — topbar 48pt com o título da aba (15pt, peso 700), depois área rolável (padding 22pt). Padrão de cada linha de ajuste: título 13pt peso 600 + descrição 11pt secundária à esquerda, controle à direita, separador 0.5pt embaixo.

- **General:**
  - *Refresh interval* — segmented control `10s / 30s / 1m / 5m`.
  - *Menu bar pair* — botão tipo popup que cicla entre os pares acompanhados (ex.: "USD/BRL ▾").
  - *Show change in menu bar* — toggle (mostra/esconde a seta de tendência).
  - *Launch at login* — toggle (usar `SMAppService` no app real).
- **Currencies:**
  - Campo de busca (filtra por par/nome).
  - Lista de **todos** os pares: handle de arraste ⠿, estrela favorito, badge, par + "Nome · Crypto/FX", cotação, e **toggle** "acompanhar" (liga/desliga aparição no popover). Ex.: GBP/USD vem desligado.
  - Botão tracejado "+ Add currency pair".
- **Appearance:**
  - *Appearance* — segmented `Light / Dark / Auto` (Auto segue o sistema). Aplica imediatamente.
  - *Accent color* — 5 swatches circulares de 26pt; selecionado tem anel duplo. Cores abaixo.
  - *Menu bar format* — segmented `Pair / Symbol / Value`.
  - *Reduce transparency* — toggle (usa painéis opacos em vez de blur).
- **About:**
  - Ícone do app 58pt (cantos 15pt, fundo accent, "$" branco 30pt, sombra accent).
  - "Copera Currency" (20pt, peso 700), "Version 1.0 (1)" (12pt secundária).
  - Texto: "Real-time currency and crypto rates, always a glance away in your menu bar." + nota "Rates shown are sample data for this prototype."
  - Botão "Check for Updates…".

---

## Interações e comportamento
- **Abrir/fechar popover:** clique no item da barra. Clicar fora fecha (no app nativo o `MenuBarExtra .window` já faz isso).
- **Abrir Ajustes:** ⚙ ou "Settings…" ou "Manage" (esta vai direto para a aba Currencies). Abrir Ajustes fecha o popover.
- **Conversor:** digitar a quantia recalcula na hora; clicar nos chips cicla a moeda (pulando a moeda já usada do outro lado); ⇅ troca os lados.
- **Favoritar:** estrela alterna; favoritos sobem na lista.
- **Acompanhar:** toggle em Currencies controla se o par aparece no popover.
- **Par da barra:** clicar numa linha do popover (ou ciclar em General) muda o par exibido.
- **Atualização:** automática no intervalo escolhido; ↻ força agora e zera o "updated Xs ago". No app real, ambos rebuscam a API.
- **Tema/accent:** mudanças em Appearance aplicam imediatamente em toda a UI.
- **Animações:** popover entra com fade + scale (0.16s, ease-out tipo `cubic-bezier(0.16,1,0.3,1)`); janela de Ajustes com fade + scale (0.2s); toggles deslizam (0.18s).

## Estado (sugestão de modelo)
```
currencies: [code: { usd, change24h, symbol, name, type(fiat|crypto), badgeColor }]
pairs: [{ id, base, quote, favorite: Bool, tracked: Bool }]
menuPairId, amount, fromCode, toCode
themeMode (.light/.dark/.auto), accentColor, menuBarFormat (.pair/.symbol/.plain)
refreshInterval (segundos), showChangeInMenuBar: Bool, launchAtLogin: Bool, reduceTransparency: Bool
search, updatedAt: Date
```
Derivados: taxa de um par, % de variação do par (`change(base) - change(quote)`), label de tempo relativo.

## Dados / API
O protótipo usa dados simulados. No app real, integre uma fonte de cotações em tempo real:
- **Fiat (forex):** ex. open.er-api.com, exchangerate.host, ou um provedor pago.
- **Cripto:** ex. CoinGecko (`/simple/price`) ou Coinbase.
- Normalize tudo para um valor em USD por unidade (como no protótipo) para facilitar conversões e taxas de qualquer par. Calcule a variação 24h a partir do preço de 24h atrás.

## Design Tokens

### Cores — tema Claro
| Token | Valor |
|---|---|
| Texto | `#1d1d1f` |
| Texto secundário | `rgba(60,60,67,0.6)` |
| Painel (popover) | `rgba(247,247,249,0.72)` + blur |
| Borda do painel | `rgba(0,0,0,0.09)` |
| Campo | `rgba(255,255,255,0.75)` |
| Borda do campo | `rgba(0,0,0,0.10)` |
| Separador | `rgba(0,0,0,0.08)` |
| Hover | `rgba(0,0,0,0.05)` |
| Barra de menu | `rgba(255,255,255,0.42)` + blur |
| Texto da barra | `#1d1d1f` |
| Fundo sidebar Ajustes | `#e7e7ea` |
| Fundo conteúdo Ajustes | `#f6f6f8` |
| Positivo (alta) | `#1a8f4c` |
| Negativo (baixa) | `#d23b32` |
| Sombra | `0 18px 60px rgba(0,0,0,0.28)` |

### Cores — tema Escuro
| Token | Valor |
|---|---|
| Texto | `#f5f5f7` |
| Texto secundário | `rgba(235,235,245,0.6)` |
| Painel (popover) | `rgba(36,36,40,0.74)` + blur |
| Borda do painel | `rgba(255,255,255,0.10)` |
| Campo | `rgba(255,255,255,0.07)` |
| Borda do campo | `rgba(255,255,255,0.13)` |
| Separador | `rgba(255,255,255,0.10)` |
| Hover | `rgba(255,255,255,0.07)` |
| Barra de menu | `rgba(0,0,0,0.40)` + blur |
| Texto da barra | `#ffffff` |
| Fundo sidebar Ajustes | `#242428` |
| Fundo conteúdo Ajustes | `#1c1c20` |
| Positivo (alta) | `#30d158` |
| Negativo (baixa) | `#ff453a` |
| Sombra | `0 18px 60px rgba(0,0,0,0.6)` |

### Cor de destaque (accent) — opções
`#D97757` (padrão, terracota) · `#2A6FDB` · `#1F8A5B` · `#7C5CFF` · `#E0322A`
- Pills de variação: verde `rgba(40,165,95,0.14)`, vermelho `rgba(214,60,50,0.14)`.
- Cores de marca cripto nos badges: BTC `#f7931a`, ETH `#627eea`.

### Tipografia
- Fonte da UI: **San Francisco** (system font) — em SwiftUI é o padrão.
- Números (cotações, conversor): **monoespaçada com dígitos tabulares** — `.monospacedDigit()` ou `Font.system(.body, design: .monospaced)`.
- Escala usada: 23 (conversor), 20 (título About), 15 (títulos), 13 (corpo/listas), 12, 11 (secundário), 10 (labels FROM/TO).
- Pesos: 700 (números/títulos), 600 (rótulos/medium), 500, 400.

### Raios, espaçamentos, controles
- Raios: popover/janela 12–13pt, cards 12pt, linhas/botões 8–9pt, pills 6pt, badge circular.
- Botões circulares do cabeçalho: 28pt. Botão swap: 30pt. Toggles: 40×23pt (knob 19pt) / 36×21pt (knob 17pt) nas listas.
- Item da barra de menu: altura ~26pt.
- Popover: 368pt de largura.
- Janela de Ajustes: 680×496pt, sidebar 208pt, topbar 48pt.

## Screenshots
Em `screenshots/` (referências visuais de alta fidelidade):
- `01-popover-light.png` — popover aberto, tema claro (conversor + lista de pares).
- `02-popover-dark.png` — popover aberto, tema escuro.
- `03-settings-general.png` — Ajustes › General (claro).
- `04-settings-currencies.png` — Ajustes › Currencies (claro).
- `05-settings-appearance.png` — Ajustes › Appearance (claro).
- `06-settings-about.png` — Ajustes › About (claro).
- `07-settings-dark.png` — Ajustes › Appearance (escuro).

## Assets
Nenhuma imagem externa. Ícone do app = quadrado arredondado com "$" — substitua pelo ícone oficial do Copera quando houver. Setas ▲▼, estrelas ★☆, chevrons ▾, swap ⇅ e o ícone de busca são glifos/símbolos — em SwiftUI use **SF Symbols** equivalentes (`arrow.up`/`arrow.down`, `star`/`star.fill`, `chevron.down`, `arrow.up.arrow.down`, `magnifyingglass`, `arrow.clockwise`, `gearshape`).

## Arquivos
- `Copera Currency.dc.html` — protótipo de referência (toda a UI, estado e tokens).
- `support.js` — runtime apenas para visualizar o protótipo (ignore na implementação).
